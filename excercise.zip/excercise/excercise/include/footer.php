<footer class="">
		<div class="container">
			
			<div class="footer-bottom">
				<div class="row">
					
					<div class="col-md-8 text-md-right">
						<div class="copyright"> 
Excersice Routine   System  </div>
					</div>
				</div>
			</div>
		</div>
	</footer>